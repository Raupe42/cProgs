#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void)
{
    system ("ls -l dschreiben?.txt");
    system ("cat dschreiben?.txt");
}